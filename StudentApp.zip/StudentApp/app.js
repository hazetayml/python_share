// Import the Express.js framework
const express = require('express');

//TODO: Include code for body-parser
const bodyParser = require('body-parser');

// Create an instance of the Express application. This app variable will be used to define routes and configure the server.
const app = express();

//TODO: Include code for Middleware to parse request bodies
app.use(bodyParser.urlencoded({extended: true}));

// Specify the port for the server to listen on
const port = 3000;

//TODO: Include code to set EJS as the view engine
app.set('view engine', 'ejs');

// In-memory data for students
let students = [
  { id: 1, name: 'Peter Tan', age: 20 },
  { id: 2, name: 'Mary Lim', age: 22 },
  { id: 3, name: 'John Ho', age: 21 }
];

// Routes for CRUD operations
// Route to retrieve and display all students
app.get('/', function(req, res) {
    //TODO: Insert code to render a view called "index" and pass the variable 'students' to the view for rendering
    res.render('index', {students});
});

// Route to get a specific student by ID
app.get('/students/:id', function(req, res) {
    // Extracting the 'id' parameter from the request parameters and converting it to an integer
    const studentId = parseInt(req.params.id);
    // Searching for a student in the 'students' array with a matching 'id'
    const student = students.find((student) => student.id === studentId);

    // Checking if a student with the specified 'id' was found
    if (student) {
        //TODO: If the student is found, render a view called "studentInfo" and pass the variable 'students' to the view for rendering.
        res.render("studentInfo", {student});
    } 
});

// Add a new student form
app.get('/addStudentForm', function(req, res) {
    //TODO: Insert code to render a view called "addStudent"
    res.render("addStudent");
});

// Add a new student
app.post('/students', function(req, res) {
    //TODO: Insert code to add a new student
    const {name, age} = req.body;
    const id = students[students.length-1].id + 1;
    const newStudent = {id, name, age};
    students.push(newStudent);
    res.redirect("/");
});

// Update a student by ID - First Find the student
app.get('/students/:id/update', function(req, res)  {
    //TODO: Insert code to find student to update based on student ID selected
    const studentId = parseInt(req.params.id);
    const updateStudent = students.find(function(students){
        return students.id === parseInt(studentId);
    });
    res.render("updateStudent", {updateStudent});
    
    
});

// Update a student by ID - Update the student information
app.post('/students/:id/update', function(req, res) {
    //TODO: Insert code to update student information entered in updateStudent form
    const studentId = parseInt(req.params.id);
    const {studentName, age} = req.body;
    const updatedStudent = {id:studentId, name:studentName, age: age};
    students = students.map(student => {
        if (student.id === studentId){
            return {...student, ...updatedStudent};
        }
        return student;
    });
    res.redirect("/");
});

// Delete a student by ID
app.get('/students/:id/delete', function(req, res) {
    const studentId = parseInt(req.params.id);

    // Filter out the deleted student
    students = students.filter(students => students.id !== studentId);
    //TODO: Insert code to Redirect back to index page after deleting the student
    res.redirect("/");
});

// Start the server and listen on the specified port
app.listen(port, () => {
  // Log a message when the server is successfully started
  console.log(`Server is running at http://localhost:${port}`);
});

